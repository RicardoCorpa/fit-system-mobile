import React from 'react';
import { Text, View, Button } from 'react-native';

export default function Tela1({ navigation }) {
  return (
    <View>
      <Text>Essa e a Tela 1</Text>

      <Button title="Home" onPress={() => navigation.navigate('Home')} />
    </View>
  );
}