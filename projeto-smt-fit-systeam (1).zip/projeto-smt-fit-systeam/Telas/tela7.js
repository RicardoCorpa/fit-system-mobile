import React from 'react';
import { Text, View, Button } from 'react-native';

export default function Tela7({ navigation }) {
  return (
    <View>
      <Text>Essa e a Tela 7</Text>

      <Button title="Home" onPress={() => navigation.navigate('Home')} />
    </View>
  );
}
